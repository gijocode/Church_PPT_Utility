Kivy Project
------------

This part of the documentation explains the basic ideas behind Kivy's design
and why you'd want to use it.

.. toctree::
    :maxdepth: 2

    philosophy
    contribute
    faq
    contact
